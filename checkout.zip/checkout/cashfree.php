    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
      <form id="redirectForm" method="post" action="checkout/request.php">
          <input class="form-control" name="orderId" value="<?php echo  "Txn" . rand(10000,99999999)?>" placeholder="<?php echo  "Txn" . rand(10000,99999999)?>"/>
          <input class="form-control" name="orderAmount" placeholder="Enter Order Amount here (Ex. 100)"/>
          <input class="form-control" name="customerName" placeholder="Enter your name here (Ex. John Doe)"/>
          <input class="form-control" name="returnUrl" placeholder="http://localhost/Gauravsinghigc.tech/payment_gateways/payumoney/index.php"/>
        <button type="submit" class="btn btn-primary btn-block" value="Pay">Submit</button>
      </form>

