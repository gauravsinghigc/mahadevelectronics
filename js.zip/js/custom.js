
function choose(element){
    //alert(element.getAttribute("value"));
    var style = element.getAttribute("value");
   // alert(style);
   var product_price = document.getElementById("product_price").value;
   
  //alert(product_price);
   var totalprice=0;
 totalprice= parseFloat(product_price) + parseFloat(style);
  // alert(totalprice);
   document.getElementById("price").innerHTML = totalprice;
 document.getElementById("hidden_price").value = totalprice;

}
